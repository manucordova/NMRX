import unittest

from .split.test_spliter import TestEnvironmentalKFold


if __name__ == '__main__':
    unittest.main()