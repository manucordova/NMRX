from ..base import np,sp

def power(x,zeta):
    return np.power(x,zeta)